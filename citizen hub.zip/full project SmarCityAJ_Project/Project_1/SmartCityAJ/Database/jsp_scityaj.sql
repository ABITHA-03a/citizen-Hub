-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2024 at 02:33 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jsp_scityaj`
--
CREATE DATABASE IF NOT EXISTS `jsp_scityaj` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `jsp_scityaj`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `userid` varchar(100) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`userid`, `pwd`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `cname` varchar(200) NOT NULL,
  PRIMARY KEY (`cname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`cname`) VALUES
('Madurai'),
('Trichy');

-- --------------------------------------------------------

--
-- Table structure for table `cityinfo`
--

CREATE TABLE IF NOT EXISTS `cityinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(200) NOT NULL,
  `infohead` varchar(100) NOT NULL,
  `descr` varchar(5000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cityinfo`
--

INSERT INTO `cityinfo` (`id`, `cname`, `infohead`, `descr`) VALUES
(1, 'Madurai', 'Temple', 'Madurai Meenakshi Amman Temple is a renowned location and the prime devotion place for all who visit the city.'),
(2, 'Madurai', 'Temple', 'Alagar Kovil is a popular temple in the madurai city.  It is also related to Meenakshi Amman Temple and Chitrai Festival.'),
(3, 'Madurai', 'Tourist Place', 'Madurai Thamukkam Ground is a tourist place for the people in the city.  It host many event in all the days of the year.');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
